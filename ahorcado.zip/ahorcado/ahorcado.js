function draw() {
    const canvas = document.getElementById("canvas");
    if (canvas.getContext) {
      const ctx = canvas.getContext("2d");

      //Dibujar base
      ctx.beginPath();
      ctx.moveTo(100,50);
      ctx.stroke();
    }
  }

  function inicar(){
    
  }